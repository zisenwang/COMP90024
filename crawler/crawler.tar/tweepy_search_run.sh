#!/usr/bin/env bash

python3 ./tweet_harvester_search.py --limit 10 --config './config.json'