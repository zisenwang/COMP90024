#!/usr/bin/env bash

python3 ./tweet_harvester_stream.py --time 10 --limit 10 --config './config.json'